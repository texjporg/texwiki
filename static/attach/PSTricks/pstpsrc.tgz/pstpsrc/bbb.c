/* 
  pgm$B%U%!%$%k$+$i@53N$K(BBounding Box ($BIA2hNN0h(B) $B$rF@$k(B
  $BL5M}$d$j$J%W%m%0%i%`(B bbb.c 
*/
#include<stdio.h>
#include<string.h>
#define buf_size 1024

struct bb {  unsigned int width, height; };

int main( void ){
  struct bb max, min, orig;
  int ch;
  int i, j;
  char bufa[buf_size];

  scanf( "%s\n", bufa);
  if( !(strcmp(bufa, "P1") == 0 ) ){
    fprintf(stderr, "Error!! Please give me correctly PGM file." );
    return 0;
  }
  gets( bufa );
  scanf( "%d%d", &orig.width, &orig.height );

  max.width=0;
  max.height=0;
  min.width=orig.width;
  min.height=orig.height;
  
  for( j=0; j < orig.height;  j++){
    for( i=0; i < orig.width; i++){
      ch = getchar();
      if ( ch == '\n' ){
	i--;
      }else if( ch == '1' ){
	if ( i < min.width )
	  min.width = i;
	if ( j < min.height )
	  min.height = j;
	if ( i > max.width ) 
	  max.width = i;
	if ( j > max.height )
	  max.height= j;
      }
    }
  }

  printf ("%%%%BoundingBox: %d %d %d %d\n", 
	  min.width-1, orig.height-max.height-1, 
	  max.width+1, orig.height-min.height+1);

  return 0;
}
