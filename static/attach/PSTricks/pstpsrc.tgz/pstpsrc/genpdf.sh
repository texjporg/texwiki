#!/bin/bash
files=`ls $1-fig*.tex`;
pstemp=`ls $1-fig.tmp`;
header=`head -1 $1.tex`;
TEX=platex
DVIPS=pdvips

if [ $OS = "Windows_NT" ]; then
    WINDOWSFLAGS="-dWINKANJI"
fi

for f in $files; do
  $TEX -jobname=`basename $f .tex` "$header \relax\pagestyle{empty}\input{$pstemp}\begin{document}\vspace*{\fill}\input{$f}\vspace*{\fill}\end{document}"
  fig=`basename $f .tex`
  $DVIPS  -Ppdf -o $fig.ps $fig
  ps2pdf14 \
    -dAutoFilterColorImages=false \
    -dAutoFilterGrayImages=false \
    -sColorImageFilter=FlateEncode \
    -sGrayImageFilter=FlateEncode \
    -dPDFSETTINGS=/prepress \
    -dUseFlateCompression=true \
    $fig.ps
  gs -q \
    -dAutoFilterColorImages=false \
    -dAutoFilterGrayImages=false \
    -dEncodeColorImages=false \
    -dEncodeGrayImages=false \
    -dEncodeMonoImages=false \
    -dBATCH \
    -dSAFER \
    -dNOPAUSE \
    $WINDOWSFLAGS \
    -sDEVICE=pbm \
    -sPAPERSIZE=a4 \
    -r72 \
    -sOutputFile=$fig.pbm  $fig.ps
  ./bbb < $fig.pbm > $fig.bb
done

